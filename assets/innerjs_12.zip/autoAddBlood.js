
var img1 ;
var img2 ;
var img3 ;
var img4;
var img5;
var img6 ;
var img7 ;
var img8 ;
var img9 ;
var img10 ;
var img11 ;
var img12 ;
var img13;
var img14 ;
var img15 ;
var img16 ;
var img17 ;

var mainimg = new android.graphics.drawable.BitmapDrawable(img1);
var villagerimg = new android.graphics.drawable.BitmapDrawable(img2);
var nothingimg = new android.graphics.drawable.BitmapDrawable(img3);
var zombieimg = new android.graphics.drawable.BitmapDrawable(img4);
var chickenimg = new android.graphics.drawable.BitmapDrawable(img5);
var cowimg = new android.graphics.drawable.BitmapDrawable(img6);
var pigimg = new android.graphics.drawable.BitmapDrawable(img7);
var sheepimg = new android.graphics.drawable.BitmapDrawable(img8);
var mooshroomimg = new android.graphics.drawable.BitmapDrawable(img10);
var wolfimg = new android.graphics.drawable.BitmapDrawable(img9);
var creeperimg = new android.graphics.drawable.BitmapDrawable(img11);
var skeletonimg = new android.graphics.drawable.BitmapDrawable(img12);
var spiderimg = new android.graphics.drawable.BitmapDrawable(img13);
var zombiepigmanimg = new android.graphics.drawable.BitmapDrawable(img14);
var slimeimg = new android.graphics.drawable.BitmapDrawable(img15);
var endermanimg = new android.graphics.drawable.BitmapDrawable(img16);
var silverfishimg = new android.graphics.drawable.BitmapDrawable(img17);

var activatedGUI=false;
var activatedChangingGUI=0;
var ticker=60;
var start=false;
var x = "?";

var NameX=140;
var NameY=32;
var HealthX=140;
var HealthY=80;

function setSelfPath(path){
	scriptPath = path;
	print(path);
	
	print("script path script path"+scriptPath);
	
	img1 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/main.png");
    img2 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/villager.png");
    img3 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/nothing.png");
 img4 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/zombie.png");
 img5 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/chicken.png");
img6 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/cow.png");
 img7 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/pig.png");
 img8 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/sheep.png");
 img9 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/wolf.png");
 img10 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/mooshroom.png");
 img11 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/creeper.png");
 img12 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/skeleton.png");
 img13 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/spider.png");
 img14 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/zombiepigman.png");
 img15 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/slime.png");
 img16 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/enderman.png");
 img17 = new android.graphics.BitmapFactory.decodeFile(scriptPath+"/DamageIndicators/silverfish.png");
}

function procCmd(command) 
{ 
	var cmd = command.split(" "); 
	if(cmd[0]=="edit")
	{
		activatedChangingGUI=1;
	}
	if(cmd[0]=="finish")
	{
		activatedChangingGUI=2;
	}
}

function modTick()
{
	var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 
	ctx.runOnUiThread(new java.lang.Runnable(){
	
	run: function(){
	if(activatedChangingGUI==1)
	{
		activatedChangingGUI=0;
		
		//调整名字位置X 按钮 -
		GUISubNameX = new android.widget.PopupWindow();
		var layout5 = new android.widget.LinearLayout(ctx);
		layout5.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUISubNameX.setContentView(layout5);
		GUISubNameX.setWidth(75);
		GUISubNameX.setHeight(75);
		var btnSubNameX = new android.widget.Button(ctx);
		layout5.addView(btnSubNameX);
		btnSubNameX.setText("-");
		btnSubNameX.setOnClickListener(new android.view.View.OnClickListener({ 
			onClick: function(viewarg)
			{
				NameX= NameX-5;
			}
		}));
		GUISubNameX.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 5, 5);

		//调整名字位置X 按钮 +
		GUIAddNameX = new android.widget.PopupWindow();
		var layout6 = new android.widget.LinearLayout(ctx);
		layout6.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUIAddNameX.setContentView(layout6);
		GUIAddNameX.setWidth(75);
		GUIAddNameX.setHeight(75);
		var btn6 = new android.widget.Button(ctx);
		layout6.addView(btn6);
		btnAddNameX.setText("+");
		btnAddNameX.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		NameX= NameX+5;
		}
		}));
		GUIAddNameX.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 5, 85);

		//调整名字位置Y 按钮-
		GUISubNameY = new android.widget.PopupWindow();
		var layout7 = new android.widget.LinearLayout(ctx);
		layout7.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUISubNameY.setContentView(layout7);
		GUISubNameY.setWidth(75);
		GUISubNameY.setHeight(75);
		var btnSubNameY = new android.widget.Button(ctx);
		layout7.addView(btnSubNameY);
		btnSubNameY.setText("-");
		btnSubNameY.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		NameY= NameY-5;
		}
		}));
		GUISubNameY.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 85, 5);

		//调整名字位置Y 按钮++
		 GUI8 = new android.widget.PopupWindow();
		var layout8 = new android.widget.LinearLayout(ctx);
		layout8.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUI8.setContentView(layout8);
		GUI8.setWidth(75);
		GUI8.setHeight(75);
		var btn8 = new android.widget.Button(ctx);
		layout8.addView(btn8);
		btn8.setText("+");
		btn8.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		NameY= NameY+5;
		}
		}));
		GUI8.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 85, 85);

		//调整血条位置按钮X -
		GUI9 = new android.widget.PopupWindow();
		var layout9 = new android.widget.LinearLayout(ctx);
		layout9.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUI9.setContentView(layout9);
		GUI9.setWidth(75);
		GUI9.setHeight(75);
		var btn9 = new android.widget.Button(ctx);
		layout9.addView(btn9);
		btn9.setText("-");
		btn9.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		HealthX= HealthX-5;
		}
		}));
		GUI9.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 5, 165);

		//调整血条位置按钮X +
		GUI10 = new android.widget.PopupWindow();
		var layout10 = new android.widget.LinearLayout(ctx);
		layout10.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUI10.setContentView(layout10);
		GUI10.setWidth(75);
		GUI10.setHeight(75);
		var btn10 = new android.widget.Button(ctx);
		layout10.addView(btn10);
		btn10.setText("+");
		btn10.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		HealthX= HealthX+5;
		}
		}));
		GUI10.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 5, 245);

		//调整血条位置按钮Y -
		GUI11 = new android.widget.PopupWindow();
		var layout11 = new android.widget.LinearLayout(ctx);
		layout11.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUI11.setContentView(layout11);
		GUI11.setWidth(75);
		GUI11.setHeight(75);
		var btn11 = new android.widget.Button(ctx);
		layout11.addView(btn11);
		btn11.setText("-");
		btn11.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		HealthY= HealthY-5;
		}
		}));
		GUI11.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 85, 165);

		//调整血条位置按钮Y +
		 GUI12 = new android.widget.PopupWindow();
		var layout12 = new android.widget.LinearLayout(ctx);
		layout12.setOrientation(android.widget.LinearLayout.VERTICAL);
		GUI12.setContentView(layout12);
		GUI12.setWidth(75);
		GUI12.setHeight(75);
		var btn12 = new android.widget.Button(ctx);
		layout12.addView(btn12);
		btn12.setText("+");
		btn12.setOnClickListener(new android.view.View.OnClickListener({ 
		onClick: function(viewarg)
		{
		HealthY= HealthY+5;
		}
		}));
		GUI12.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 85, 245);
	}
	else if(activatedChangingGUI==2)
	{
		GUISubNameX.dismiss();
		GUIAddNameX.dismiss();
		GUISubNameY.dismiss();
		GUI8.dismiss();
		GUI9.dismiss();
		GUI10.dismiss();
		GUI11.dismiss();
		GUI12.dismiss();
	}
	}
	})

	if(start==true)
	{
		ticker--;
	}
	if(ticker==0)
	{
		start=false;
		ticker=60;
		var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 
		ctx.runOnUiThread(new java.lang.Runnable(){
			run: function(){
			GUI.dismiss();
			GUI2.dismiss();
			GUI3.dismiss();
			GUI4.dismiss();
			}
		})
	}
}

function attackHook(attacker, victim)
{
	if(Entity.getEntityTypeId(victim)==15)
	{
		x="10";
	}
	else if(Entity.getEntityTypeId(victim)==10)
	{
		x="4"; 
	}
	else if(Entity.getEntityTypeId(victim)==11)
	{
		x="10"; 
	}
	else if(Entity.getEntityTypeId(victim)==12)
	{
		x="10"; 
	}
	else if(Entity.getEntityTypeId(victim)==13)
	{
		x="8"; 
	}
	else if(Entity.getEntityTypeId(victim)==14)
	{
		x="10"; 
	}
	else if(Entity.getEntityTypeId(victim)==16)
	{
		x="10"; 
	}
	else if(Entity.getEntityTypeId(victim)==32)
	{
		x="20"; 
	}
	else if(Entity.getEntityTypeId(victim)==33)
	{
		x="20"; 
	}
	else if(Entity.getEntityTypeId(victim)==34)
	{
		x="15"; 
	}
	else if(Entity.getEntityTypeId(victim)==35)
	{
		x="16"; 
	}
	else if(Entity.getEntityTypeId(victim)==36)
	{
		x="20"; 
	}
	else if(Entity.getEntityTypeId(victim)==37)
	{
		x="[1] [4] [16]"; 
	}
	else if(Entity.getEntityTypeId(victim)==38)
	{
		x="40"; 
	}
	else if(Entity.getEntityTypeId(victim)==39)
	{
		x="8"; 
	}

	var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 
	ctx.runOnUiThread(
		new java.lang.Runnable()
		{
			run: function()
			{ 
				try{
				if(activatedGUI==true)
				{
					GUI.dismiss();
					GUI2.dismiss();
					GUI3.dismiss();
					GUI4.dismiss();
					activatedGUI=false;
				}

				activatedGUI=true;
				GUI = new android.widget.PopupWindow();
				var layout = new android.widget.LinearLayout(ctx);
				layout.setOrientation(android.widget.LinearLayout.VERTICAL);
				GUI.setContentView(layout);
				GUI.setWidth(405);
				GUI.setHeight(105);
				var btn = new android.widget.Button(ctx);
				layout.addView(btn);
				btn.setBackgroundDrawable(mainimg);
				btn.setText("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
				GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 10, 40);

				GUI2 = new android.widget.PopupWindow();
				var layout2 = new android.widget.LinearLayout(ctx);
				layout2.setOrientation(android.widget.LinearLayout.VERTICAL);
				GUI2.setContentView(layout2);
				GUI2.setWidth(37);
				GUI2.setHeight(75);
				var btn2 = new android.widget.Button(ctx);
				layout2.addView(btn2);
				if(Entity.getEntityTypeId(victim)==15)
				{
					btn2.setBackgroundDrawable(villagerimg);
				}
				else if(Entity.getEntityTypeId(victim)==10)
				{
					btn2.setBackgroundDrawable(chickenimg);
				}
				else if(Entity.getEntityTypeId(victim)==11)
				{
					btn2.setBackgroundDrawable(cowimg);
				}
				else if(Entity.getEntityTypeId(victim)==12)
				{
					btn2.setBackgroundDrawable(pigimg);
				}
				else if(Entity.getEntityTypeId(victim)==13)
				{
					btn2.setBackgroundDrawable(sheepimg);
				}
				else if(Entity.getEntityTypeId(victim)==14)
				{
					btn2.setBackgroundDrawable(wolfimg);
				}
				else if(Entity.getEntityTypeId(victim)==16)
				{
					btn2.setBackgroundDrawable(mooshroomimg);
				}
				else if(Entity.getEntityTypeId(victim)==32)
				{
					btn2.setBackgroundDrawable(zombieimg);
				}
				else if(Entity.getEntityTypeId(victim)==33)
				{
					btn2.setBackgroundDrawable(creeperimg);
				}
				else if(Entity.getEntityTypeId(victim)==34)
				{
					btn2.setBackgroundDrawable(skeletonimg);
				}
				else if(Entity.getEntityTypeId(victim)==35)
				{
					btn2.setBackgroundDrawable(spiderimg);
				}
				else if(Entity.getEntityTypeId(victim)==36)
				{
					btn2.setBackgroundDrawable(zombiepigmanimg);
				}
				else if(Entity.getEntityTypeId(victim)==37)
				{
					btn2.setBackgroundDrawable(slimeimg);
				}
				else if(Entity.getEntityTypeId(victim)==38)
				{
					btn2.setBackgroundDrawable(endermanimg);
				}
				else if(Entity.getEntityTypeId(victim)==39)
				{
					btn2.setBackgroundDrawable(silverfishimg);
				}
				
				btn2.setText("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
				GUI2.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 45, 55);

				GUI3 = new android.widget.PopupWindow();
				var layout3 = new android.widget.LinearLayout(ctx);
				layout3.setOrientation(android.widget.LinearLayout.VERTICAL);
				GUI3.setContentView(layout3);
				GUI3.setWidth(250);
				GUI3.setHeight(250);
				var btn3 = new android.widget.Button(ctx);
				layout3.addView(btn3);
				btn3.setBackgroundDrawable(nothingimg);
				if(Entity.getEntityTypeId(victim)==15)
				{
					btn3.setText("Villager"); 
				}
				else if(Entity.getEntityTypeId(victim)==10)
				{
					btn3.setText("Chicken"); 
				}
				else if(Entity.getEntityTypeId(victim)==11)
				{
					btn3.setText("Cow"); 
				}
				else if(Entity.getEntityTypeId(victim)==12)
				{
					btn3.setText("Pig"); 
				}
				else if(Entity.getEntityTypeId(victim)==13)
				{
					btn3.setText("Sheep"); 
				}
				else if(Entity.getEntityTypeId(victim)==14)
				{
					btn3.setText("Wolf"); 
				}
				else if(Entity.getEntityTypeId(victim)==16)
				{
					btn3.setText("Mooshroom"); 
				}
				else if(Entity.getEntityTypeId(victim)==32)
				{
					btn3.setText("Zombie"); 
				}
				else if(Entity.getEntityTypeId(victim)==33)
				{
					btn3.setText("Creeper"); 
				}
				else if(Entity.getEntityTypeId(victim)==34)
				{
					btn3.setText("Skeleton"); 
				}
				else if(Entity.getEntityTypeId(victim)==35)
				{
					btn3.setText("Spider"); 
				}
				else if(Entity.getEntityTypeId(victim)==36)
				{
					btn3.setText("Zombie Pigman"); 
				}
				else if(Entity.getEntityTypeId(victim)==37)
				{
					btn3.setText("Slime"); 
				}
				else if(Entity.getEntityTypeId(victim)==38)
				{
					btn3.setText("Enderman"); 
				}
				else if(Entity.getEntityTypeId(victim)==39)
				{
					btn3.setText("Silverfish"); 
				}
				GUI3.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, NameX, NameY);

				GUI4 = new android.widget.PopupWindow();
				var layout4 = new android.widget.LinearLayout(ctx);
				layout4.setOrientation(android.widget.LinearLayout.VERTICAL);
				GUI4.setContentView(layout4);
				GUI4.setWidth(250);
				GUI4.setHeight(250);
				var btn4 = new android.widget.Button(ctx);
				layout4.addView(btn4);
				btn4.setBackgroundDrawable(nothingimg);

				btn4.setText(Entity.getHealth(victim)+ " / "+x);

				GUI4.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, HealthX, HealthY);
				}
				catch(e)
				{
					
				}
			}
		})
	start=true;
}
