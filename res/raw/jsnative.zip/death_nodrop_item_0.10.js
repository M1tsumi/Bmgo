var die = false;
var id = new Array(), data = new Array(), count = new Array();
var id_a = new Array(), data_a = new Array();
var enable_script_var = 1;

function deathHook(attacker, entity) {
    if (entity != getPlayerEnt()) return;
	id = [];
    data = [];
    count = [];
	id_a = [];
    data_a = [];
	
    die = true

    for (i = 0; i < 36; i++) {
        id.push(Player.getInventorySlot(i));
		data.push(Player.getInventorySlotData(i));
		count.push(Player.getInventorySlotCount(i));
		Player.clearInventorySlot(i);
    }
	
	for(j=0; j<4; j++){
		id_a.push(Player.getArmorSlot(j));
		data_a.push(Player.getArmorSlotDamage(j));
	}
}

function modTick() {
	if ( enable_script_var == 0 )return;
	
    if (die == true && Entity.getHealth(getPlayerEnt()) > 0) {
        die = false
        for (i = 0; i < 36; i++){
			Player.addItemInventory(id[i], count[i], data[i]);
		}
    }
}

function enable_script_func() {
	enable_script_var = 1;
}

function disable_script_func() {
	enable_script_var = 0;
}
