//MiniMap mod
//Copyright 2015 MxGoldo
var curVersion = 2.0;
var X, Z, YAW;
var redraw = false, startMapControl = true;
var settings = {}, settingsLoaded = false;
var minZoom, bmpSrc, bmpSrcCopy;
var canvasBmpSrc = new android.graphics.Canvas();
var canvasBmpSrcCopy = new android.graphics.Canvas();
var matrixMap = new android.graphics.Matrix();
var matrixPointer = new android.graphics.Matrix();
var bmpSrcLock = new java.util.concurrent.Semaphore(1, true);
var delayChunksArrLock = new java.util.concurrent.Semaphore(1,true);
var delayChunksArr = [];
var pool, poolTick, scheduledFutureUpdateMap, runnableUpdateMap;
var context = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
var mapWindow, setWindow;
var density = context.getResources().getDisplayMetrics().density;
var displayHeight = (context.getResources().getDisplayMetrics().widthPixels < context.getResources().getDisplayMetrics().heightPixels) ? context.getResources().getDisplayMetrics().widthPixels : context.getResources().getDisplayMetrics().heightPixels;
var enable_script_var = 0;

(function() {
	var i, settingsString, d = Math.floor(new Date().getTime() / 1000);
	
	settingsString = 0;
	/*
	settingsString = load(
			android.os.Environment.getExternalStorageDirectory().getPath()
					+ "/games/com.mojang/minecraftpe/mods/", "minimap.txt")
			.split("\n");
			*/
			

	/*
	if(checkFileExists(decode("YXBwX21vZHNjcmlwdHMvTWluaU1hcF9Nb2RfTXhHb2xkbyB2Mi4wLmpz"))){
		settingsLoaded = true ;
	} else {
		settingsLoaded = false ;
	}
	*/
	settingsLoaded = true;

	for (i = 0; i < settingsString.length; i += 1) {
		settings[settingsString[i].split(":")[0]] = parseFloat(settingsString[i]
				.split(":")[1]);
	}
	if (settings.version !== curVersion && settingsLoaded) {
		settings = {
			radius : 4,
			map_on : 1,
			map_type : 1,
			map_zoom : 80,
			window_rawSize : 1,
			window_size : displayHeight * 0.35,
			window_rawPosition : 1,
			window_gravity : 53,
			window_y : displayHeight * 0.09,
			style_border : 1,
			style_pointer : 1,
			style_shape : 0,
			show_info : 1,
			show_zoomBtn : 1,
			delay : 20,
			threadCount : 4,
			updateCheck : 1,
			updateCheckTime : 0,
			updateVersion : curVersion,
			version : curVersion
		}
	}
	bmpSrc = android.graphics.Bitmap.createBitmap(
			((settings.radius + 1) * 2 + 1) * 16,
			((settings.radius + 1) * 2 + 1) * 16,
			android.graphics.Bitmap.Config.ARGB_8888);
	bmpSrcCopy = android.graphics.Bitmap.createBitmap(bmpSrc.getWidth(), bmpSrc
			.getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
	canvasBmpSrc.setBitmap(bmpSrc);
	canvasBmpSrcCopy.setBitmap(bmpSrcCopy);
	minZoom = settings.window_size / (settings.radius * 2 * 16);
	
	/*
	//check update
	new java.lang.Thread(
			function() {
				android.os.Process
						.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
				var newVersion;
				if (Math.floor(settings.updateCheckTime / 86400) < Math
						.floor(d / 86400)
						&& settings.updateCheck) {
					newVersion = parseFloat(loadTxtFromUrl("https://raw.githubusercontent.com/MxGoldo/MCPE-mod-scripts/master/MiniMap_Mod_version"));
					if (!isNaN(newVersion)) {
						settings.updateCheckTime = d;
					}
					if (newVersion > curVersion) {
						settings.updateVersion = newVersion;
					}
					saveSettings();
				}
				if (settings.updateVersion > curVersion && settings.updateCheck) {
					context
							.runOnUiThread(function() {
								settingsUI(
										[
												"MiniMap Mod",
												"Ok",
												[
														"keyValue",
														"text",
														"New version available !\nYour version: "
																+ curVersion
																		.toFixed(1)
																+ "\nLatest version: "
																+ settings.updateVersion
																		.toFixed(1),
														"" ],
												[ "checkBox", "updateCheck",
														"Check for updates" ] ])
										.show();
							});
				}
			}).start();
	*/
	
	runnableUpdateMap = new java.lang.Runnable(
			function() {
				try {
					android.os.Process
							.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
					var xNew = Player.getX(), zNew = Player.getZ(), yawNew = getYaw(), xChunkNew, zChunkNew, xChunkOld, zChunkOld, i, ix, radius = settings.radius * 16;
					if (xNew !== X || zNew !== Z || redraw) {
						redraw = false;
						xChunkNew = Math.floor(xNew / 16) * 16;
						zChunkNew = Math.floor(zNew / 16) * 16;
						xChunkOld = Math.floor(X / 16) * 16;
						zChunkOld = Math.floor(Z / 16) * 16;
						if (xChunkNew !== xChunkOld || zChunkNew !== zChunkOld) {
							if (Math.abs(xChunkNew - xChunkOld) <= radius * 2
									&& Math.abs(zChunkNew - zChunkOld) <= radius * 2) {
								try {
									bmpSrcLock.acquire();
									bmpSrcCopy.eraseColor(0);
									canvasBmpSrcCopy.drawBitmap(bmpSrc,
											zChunkNew - zChunkOld, xChunkOld
													- xChunkNew, null);
									bmpSrc.eraseColor(0);
									canvasBmpSrc.drawBitmap(bmpSrcCopy, 0, 0,
											null);
								} finally {
									X = xNew;
									Z = zNew;
									bmpSrcLock.release();
								}
								if (xChunkNew > xChunkOld) {
									for (i = radius + 16
											- (xChunkNew - xChunkOld); i <= radius; i += 16) {
										newDrawChunkRunnable(xChunkNew + i,
												zChunkNew, 0);
										for (ix = 16; ix <= radius; ix += 16) {
											newDrawChunkRunnable(xChunkNew + i,
													zChunkNew + ix, 0);
											newDrawChunkRunnable(xChunkNew + i,
													zChunkNew - ix, 0);
										}
									}
								} else if (xChunkOld > xChunkNew) {
									for (i = radius + 16
											- (xChunkOld - xChunkNew); i <= radius; i += 16) {
										newDrawChunkRunnable(xChunkNew - i,
												zChunkNew, 0);
										for (ix = 16; ix <= radius; ix += 16) {
											newDrawChunkRunnable(xChunkNew - i,
													zChunkNew + ix, 0);
											newDrawChunkRunnable(xChunkNew - i,
													zChunkNew - ix, 0);
										}
									}
								}
								if (zChunkNew > zChunkOld) {
									for (i = radius + 16
											- (zChunkNew - zChunkOld); i <= radius; i += 16) {
										newDrawChunkRunnable(xChunkNew,
												zChunkNew + i, 0);
										for (ix = 16; ix <= radius; ix += 16) {
											newDrawChunkRunnable(
													xChunkNew + ix, zChunkNew
															+ i, 0);
											newDrawChunkRunnable(
													xChunkNew - ix, zChunkNew
															+ i, 0);
										}
									}
								} else if (zChunkOld > zChunkNew) {
									for (i = radius + 16
											- (zChunkOld - zChunkNew); i <= radius; i += 16) {
										newDrawChunkRunnable(xChunkNew,
												zChunkNew - i, 0);
										for (ix = 16; ix <= radius; ix += 16) {
											newDrawChunkRunnable(
													xChunkNew + ix, zChunkNew
															- i, 0);
											newDrawChunkRunnable(
													xChunkNew - ix, zChunkNew
															- i, 0);
										}
									}
								}
							} else {
								X = xNew;
								Z = zNew;
								bmpSrc.eraseColor(0);
								newDrawChunkRunnable(xChunkNew, zChunkNew, 0);
								for (i = 16; i <= settings.radius * 16; i += 16) {
									for (ix = 0; ix < i; ix += 16) {
										newDrawChunkRunnable(xChunkNew + ix
												+ 16, zChunkNew + i, 0);
										newDrawChunkRunnable(xChunkNew + ix,
												zChunkNew - i, 0);
										newDrawChunkRunnable(xChunkNew - ix,
												zChunkNew + i, 0);
										newDrawChunkRunnable(xChunkNew - ix
												- 16, zChunkNew - i, 0);
										newDrawChunkRunnable(xChunkNew + i,
												zChunkNew + ix, 0);
										newDrawChunkRunnable(xChunkNew + i,
												zChunkNew - ix - 16, 0);
										newDrawChunkRunnable(xChunkNew - i,
												zChunkNew + ix + 16, 0);
										newDrawChunkRunnable(xChunkNew - i,
												zChunkNew - ix, 0);
									}
								}
							}
						} else {
							X = xNew;
							Z = zNew;
						}
						matrixMap.setTranslate(settings.window_size * 0.5
								- (bmpSrc.getWidth() * 0.5) - 8 + zNew
								- zChunkNew, settings.window_size * 0.5
								- (bmpSrc.getHeight() * 0.5) + 8 - xNew
								+ xChunkNew);
						matrixMap.postScale(
								(100 / settings.map_zoom) * minZoom,
								(100 / settings.map_zoom) * minZoom,
								settings.window_size * 0.5,
								settings.window_size * 0.5);
						mapWindow.setMap();
					}
					if (yawNew !== YAW) {
						if (settings.style_pointer) {
							matrixPointer.setRotate(yawNew - 90,
									settings.window_size * 0.5,
									settings.window_size * 0.5);
							mapWindow.setPointer();
						}
						YAW = yawNew;
					}
				} catch (e) {
					//print("updateMap, " + e);
				}
			});
}());
function modTick() {
		if(enable_script_var == 0 )
	{
		try {
			if (mapWindow) {
				mapWindow.hide();
			}
			if (settings.map_on) {
				scheduledFutureUpdateMap.cancel(false);
				pool.shutdownNow();
			}
			startMapControl = true;
			X = undefined;
		} catch (e) {
			//print("leaveGame, " + e);
		}
		return ;
	}
	else
	{
		if (startMapControl) {
			startMapControl = false;
			startMap()
		}
	}
}
function leaveGame() {
	try {
		if (mapWindow) {
			mapWindow.hide();
		}
		if (settings.map_on) {
			scheduledFutureUpdateMap.cancel(false);
			pool.shutdownNow();
		}
		startMapControl = true;
		X = undefined;
	} catch (e) {
		//print("leaveGame, " + e);
	}
}
function startMap() {

	
	if (settingsLoaded) {
		if (settings.map_on) {
			pool = java.util.concurrent.Executors
					.newScheduledThreadPool(settings.threadCount);
			pool.setKeepAliveTime(60, java.util.concurrent.TimeUnit.SECONDS);
			pool.allowCoreThreadTimeOut(true);
		}
		if (!poolTick) {
			poolTick = java.util.concurrent.Executors
					.newSingleThreadScheduledExecutor();
		}
		if (!mapWindow) {
			mapWindow = createMapWindow();
		}
		if (settings.map_on) {
			scheduledFutureUpdateMap = poolTick.scheduleWithFixedDelay(
					runnableUpdateMap, 1000, Math.round(1000 / settings.delay),
					java.util.concurrent.TimeUnit.MILLISECONDS);
		}
		mapWindow.show();
	} else {
		clientMessage(ChatColor.RED + "MiniMap Mod Error: wrong script name,\n"
				+ ChatColor.RED + "change it to " + ChatColor.YELLOW
				+ "MiniMap_Mod_MxGoldo v2.0.js");
	}
}
function newDrawChunkRunnable(xChunk, zChunk, delay) {
	pool
			.schedule(
					new java.lang.Runnable(
							function() {
								try {
									android.os.Process
											.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
									if (Math.abs(Math.floor((Z - zChunk) / 16)) > settings.radius
											|| Math.abs(Math
													.floor((X - xChunk) / 16)) > settings.radius) {
										return;
									}
									var ix = 16, iz = 16, x = xChunk + 16, z = zChunk - 1, mapDotArray = [], type = settings.map_type;
									if (Level.getTile(x - 16, 0, z + 16) === 95) {
										return;
									}
									if (!chunkLoaded(x - 16, z + 16)) {
										if (settings.map_on) {
											newDrawChunkRunnable(xChunk,
													zChunk, 10);
										} else {
											delayChunksArrLock.acquire();
											delayChunksArr[delayChunksArr.length] = [
													xChunk, zChunk ];
											delayChunksArrLock.release();
										}
										return;
									}
									do {
										do {
											mapDotArray[mapDotArray.length] = mapDot[type]
													(x - ix, z + iz);
										} while (iz -= 1);
										iz = 16;
									} while (ix -= 1);
									if (java.lang.Thread.interrupted()) {
										return;
									}
									try {
										bmpSrcLock.acquire();
										bmpSrc
												.setPixels(
														mapDotArray,
														0,
														16,
														((Math.floor(Z / 16)
																+ settings.radius + 1) * 16)
																- zChunk,
														xChunk
																- ((Math
																		.floor(X / 16)
																		- settings.radius - 1) * 16),
														16, 16);
									} finally {
										bmpSrcLock.release();
									}
									redraw = true;
								} catch (e) {
									// print("drawChunk, " + e);
								}
							}), delay, java.util.concurrent.TimeUnit.SECONDS);
}
function createMapWindow() {
	var imgMap = new android.widget.ImageView(context);
	var imgPointer = new android.widget.ImageView(context);
	var btnSet = new android.widget.Button(context);
	var btnZoomIn = new android.widget.Button(context);
	var btnZoomOut = new android.widget.Button(context);
	var textInfo = new android.widget.TextView(context); 
	var mapLp = new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT); 
	var btnZoomInLp = new android.widget.RelativeLayout.LayoutParams(40 * density, 40 * density);
	var btnZoomOutLp = new android.widget.RelativeLayout.LayoutParams(40 * density, 40 * density);
	var textInfoLp = new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
	
	var layout = new android.widget.RelativeLayout(context);
	var mapWin = new android.widget.PopupWindow(layout,android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
	
	var bmpMapShow = drawForeground();
	var bmpPointerShow = android.graphics.Bitmap
			.createBitmap(settings.window_size, settings.window_size,
					android.graphics.Bitmap.Config.ARGB_8888);
	var bmpPointer = drawPointer();
	var bmpPaint = new android.graphics.Paint();
	var canvasBmpMapShow = new android.graphics.Canvas(bmpMapShow);
	var canvasBmpPointerShow = new android.graphics.Canvas(bmpPointerShow);
	
	var btnActions = {
		set : function() {
			if (!setWindow) {
				var setOptions = [
					"小地图配置选项",
					"确定",
					[
						"keyValue",
						"multipleChoice",
						"地图位置",
						"window_rawPosition",
						[ "左上", "右上","左下", "右下" ],
						"window_gravity", 
						[ 51, 53, 83, 85 ],
						"window_y", 
						[ 0, 40 * density, 0, 0 ] 
					]
				];
				
				setWindow = settingsUI(setOptions).show();
				/*
				setWindow = settingsUI(
						[
								"小地图配置选项",
								"确定",
								[ "sectionDivider", "Graphics" ],
								[
										"keyValue",
										"multipleChoice",
										"MiniMap type",
										"map_type",
										[ "basic surface (fastest)", "surface",
												"cave" ] ],
								[ "keyValue", "slider",
										"Minimap render distance", "radius", 1,
										checkRenderDistance() + 4, 1, " chunks" ],
								[ "keyValue", "slider", "Zoom", "map_zoom", 10,
										100, 1, "%" ],
								[ "sectionDivider", "View" ],
								[
										"keyValue",
										"multipleChoice",
										"Size",
										"window_rawSize",
										[ "small", "normal", "large" ],
										"window_size",
										[ displayHeight * 0.2,
												displayHeight * 0.35,
												displayHeight * 0.5 ] ],
								[
										"keyValue",
										"multipleChoice",
										"Position",
										"window_rawPosition",
										[ "top left", "top right",
												"bottom left", "bottom right" ],
										"window_gravity", [ 51, 53, 83, 85 ],
										"window_y", [ 0, 40 * density, 0, 0 ] ],
								[ "checkBox", "show_info",
										"Coordinates visible" ],
								[ "checkBox", "show_zoomBtn",
										"Zoom Buttons visible" ],
								[ "sectionDivider", "Style" ],
								[
										"keyValue",
										"multipleChoice",
										"pointer style",
										"style_pointer",
										[ "crosshairs", "arrow", "minecraft",
												"none" ] ],
								[ "keyValue", "multipleChoice", "border style",
										"style_border",
										[ "colourful", "simple", "none" ] ],
								[ "keyValue", "multipleChoice", "window shape",
										"style_shape", [ "square", "circle" ] ],
								[ "sectionDivider", "Other" ],
								[
										"checkBox",
										"updateCheck",
										"Check for updates "
												+ (settings.updateVersion > curVersion ? "(update available)"
														: "") ],
								[
										"subScreen",
										"Advanced ",
										[
												"Advanced",
												"Ok",
												[
														"keyValue",
														"slider",
														"Minimap max frequency",
														"delay", 1, 40, 1,
														" fps" ],
												[ "keyValue", "slider",
														"Threads count",
														"threadCount", 1, 12,
														1, "" ] ] ],
								[
										"subScreen",
										"MiniMap Mod info ",
										[
												"MiniMap Mod info",
												"Ok",
												[ "keyValue", "text",
														"Version ",
														curVersion.toFixed(1) ],
												[ "keyValue", "text",
														"Made by", "MxGoldo" ] ] ] ])
						.show();
				*/
			} else {
				setWindow.show();
			}
		},
		toggle : function() {
			settings.map_on = settings.map_on ? 0 : 1;
			settingsChanged("map_on");
			saveSettings();
		}
	};
	bmpPaint.setXfermode(new android.graphics.PorterDuffXfermode(
			android.graphics.PorterDuff.Mode.SRC));
	if (settings.style_border !== 2) {
		canvasBmpMapShow.clipPath(createPath(false, true),
				android.graphics.Region.Op.REPLACE);
	} else {
		canvasBmpMapShow.clipPath(createPath(true, false),
				android.graphics.Region.Op.REPLACE);
	}
	imgPointer.setVisibility(settings.map_on ? android.view.View.VISIBLE
			: android.view.View.GONE);
	if (!settings.style_pointer) {
		imgPointer.setImageBitmap(bmpPointer);
	}
	imgMap.setId(1);
	imgMap.setBackgroundColor(settings.style_shape ? 0 : -12303292);
	imgMap.setImageBitmap(bmpMapShow);
	imgMap.setVisibility(settings.map_on ? android.view.View.VISIBLE
			: android.view.View.GONE);
	mapLp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_TOP);
	imgMap.setOnClickListener(function(v) {
		btnActions.toggle();
	});
	
	imgMap.setOnLongClickListener(function(v) {
		/*btnActions.set();*/
		return true;
	});
	
	btnSet.setBackgroundResource(android.R.drawable.ic_menu_mylocation);
	btnSet.setVisibility(settings.map_on ? android.view.View.GONE
			: android.view.View.VISIBLE);
	btnSet.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
			40 * density, 40 * density));
	btnSet.setOnClickListener(function(v) {
		btnActions.toggle();
	});
	
	btnSet.setOnLongClickListener(function(v) {
		/*btnActions.set();*/
		return true;
	});
	
	textInfo.setId(2);
	textInfo
			.setVisibility(settings.map_on && settings.show_info ? android.view.View.VISIBLE
					: android.view.View.GONE);
	textInfoLp.addRule(android.widget.RelativeLayout.BELOW, 1);
	textInfoLp.addRule(android.widget.RelativeLayout.ALIGN_LEFT, 1);
	textInfoLp.addRule(android.widget.RelativeLayout.ALIGN_RIGHT, 1);
	textInfo.setTextSize(15);
	textInfo.setPadding(3 * density, 0, 0, 0);
	textInfo
			.setBackgroundColor(android.graphics.Color.argb(204, 136, 136, 136));
	textInfo.setTextColor(android.graphics.Color.WHITE);
	btnZoomOut.setId(3);
	btnZoomOut
			.setVisibility(settings.map_on && settings.show_zoomBtn ? android.view.View.VISIBLE
					: android.view.View.GONE);
	btnZoomOutLp.addRule(android.widget.RelativeLayout.BELOW, 2);
	btnZoomOut.setText("-");
	btnZoomOut.setTextSize(15);
	btnZoomOut.setTextColor(android.graphics.Color.WHITE);
	btnZoomOut.setBackgroundDrawable(drawBtnBack(40 * density, 40 * density));
	btnZoomOut.setOnClickListener(function(v) {
		if (settings.map_zoom * 1.2 >= 100) {
			android.widget.Toast.makeText(context, "Unable to zoom out anymore",
					android.widget.Toast.LENGTH_SHORT).show();
			settings.map_zoom = 100;
		} else {
			settings.map_zoom = Math.round(settings.map_zoom * 1.2);
		}
		redraw = true;
		saveSettings();
	});
	btnZoomIn.setId(4);
	btnZoomIn
			.setVisibility(settings.map_on && settings.show_info ? android.view.View.VISIBLE
					: android.view.View.GONE);
	btnZoomInLp.addRule(android.widget.RelativeLayout.BELOW, 2);
	btnZoomInLp.addRule(android.widget.RelativeLayout.RIGHT_OF, 3);
	btnZoomIn.setText("+");
	btnZoomIn.setTextSize(15);
	btnZoomIn.setTextColor(android.graphics.Color.WHITE);
	btnZoomIn.setBackgroundDrawable(drawBtnBack(40 * density, 40 * density));
	btnZoomIn.setOnClickListener(function(v) {
		if (settings.map_zoom * 0.8 <= 10) {
			android.widget.Toast.makeText(context, "Unable to zoom in anymore",
					android.widget.Toast.LENGTH_SHORT).show();
			settings.map_zoom = 10;
		} else {
			settings.map_zoom = Math.round(settings.map_zoom * 0.8);
		}
		redraw = true;
		saveSettings();
	});
	layout.addView(btnSet);
	layout.addView(imgMap, mapLp);
	layout.addView(imgPointer, mapLp);
	layout.addView(btnZoomIn, btnZoomInLp);
	layout.addView(btnZoomOut, btnZoomOutLp);
	layout.addView(textInfo, textInfoLp);
	mapWin.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
			android.graphics.Color.TRANSPARENT));
	return {
		setMap : function() {
			canvasBmpMapShow.drawBitmap(bmpSrc, matrixMap, bmpPaint);
			context.runOnUiThread(function() {
				if (settings.show_info) {
					textInfo.setText("X:" + Math.floor(Player.getX()) + " Y:"
							+ Math.floor(Player.getY() - 2) + " Z:"
							+ Math.floor(Player.getZ()));
				}
				imgMap.setImageBitmap(bmpMapShow);
			});
		},
		setPointer : function() {
			canvasBmpPointerShow
					.drawBitmap(bmpPointer, matrixPointer, bmpPaint);
			context.runOnUiThread(function() {
				imgPointer.setImageBitmap(bmpPointerShow);
			});
		},
		reset : function(part) {
			switch (part) {
			case "size":
				bmpPointerShow = android.graphics.Bitmap.createBitmap(
						settings.window_size, settings.window_size,
						android.graphics.Bitmap.Config.ARGB_8888);
				canvasBmpPointerShow.setBitmap(bmpPointerShow);
				break;
			case "window":
				context.runOnUiThread(function() {
					bmpMapShow = drawForeground();
					canvasBmpMapShow.setBitmap(bmpMapShow);
					imgMap.setBackgroundColor(settings.style_shape ? 0
							: -12303292);
					if (settings.style_border !== 2) {
						canvasBmpMapShow.clipPath(createPath(false, true),
								android.graphics.Region.Op.REPLACE);
					} else {
						canvasBmpMapShow.clipPath(createPath(true, false),
								android.graphics.Region.Op.REPLACE);
					}
					imgMap.setImageBitmap(bmpMapShow);
					redraw = true;
				});
				break;
			case "pointer":
				context.runOnUiThread(function() {
					bmpPointer = drawPointer();
					imgPointer.setImageBitmap(bmpPointer);
					YAW = undefined;
				});
				break;
			case "visibility":
				context
						.runOnUiThread(function() {
							var visible = android.view.View.VISIBLE, gone = android.view.View.GONE;
							if (settings.map_on) {
								btnSet.setVisibility(gone);
								imgMap.setVisibility(visible);
								imgPointer.setVisibility(visible);
								btnZoomIn
										.setVisibility(settings.show_zoomBtn ? visible
												: gone);
								btnZoomOut
										.setVisibility(settings.show_zoomBtn ? visible
												: gone);
								textInfo
										.setVisibility(settings.show_info ? visible
												: gone);
							} else {
								btnSet.setVisibility(visible);
								imgMap.setVisibility(gone);
								imgPointer.setVisibility(gone);
								btnZoomIn.setVisibility(gone);
								btnZoomOut.setVisibility(gone);
								textInfo.setVisibility(gone);
							}
						});
				break;
			case "position":
				context.runOnUiThread(function() {
					mapWin.dismiss();
					mapWin.showAtLocation(context.getWindow().getDecorView(),
							settings.window_gravity, 0, settings.window_y);
				});
				break;
			}
		},
		show : function() {
			context.runOnUiThread(function() {
				mapWin.showAtLocation(context.getWindow().getDecorView(),
						settings.window_gravity, 0, settings.window_y);
			});
		},
		hide : function() {
			context.runOnUiThread(function() {
				mapWin.dismiss();
			});
		}
	};
}
function decode(string) {
	return new java.lang.String(android.util.Base64.decode(string, 0), "UTF-8");
}

function checkFileExists(path) {
	var context = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(), ctx = new android.content.ContextWrapper(
			context);
	return java.io.File(ctx.getApplicationInfo().dataDir + "/" + path).exists()
}

function drawBtnBack(width, height) {
	var bmp = android.graphics.Bitmap.createBitmap(width, height,
			android.graphics.Bitmap.Config.ARGB_8888), canvas = new android.graphics.Canvas(
			bmp), paint = new android.graphics.Paint(), drawable;
	paint.setColor(android.graphics.Color.GRAY);
	paint.setMaskFilter(new android.graphics.EmbossMaskFilter([ 1, 1, 0.3 ],
			0.7, 8, 4 * density));
	canvas.drawRect(0, 0, width, height, paint);
	drawable = new android.graphics.drawable.BitmapDrawable(bmp);
	drawable.setAlpha(204);
	return drawable;
}
function drawPointer() {
	var bmp = android.graphics.Bitmap.createBitmap(settings.window_size,
			settings.window_size, android.graphics.Bitmap.Config.ARGB_8888), canvas = new android.graphics.Canvas(
			bmp), paint = new android.graphics.Paint(), matrix = new android.graphics.Matrix(), temp;
	switch (settings.style_pointer) {
	case 1:
		temp = new android.graphics.Path();
		temp.lineTo(-displayHeight * 0.0125, displayHeight * 0.025);
		temp.lineTo(0, displayHeight * 0.015);
		temp.lineTo(displayHeight * 0.0125, displayHeight * 0.025);
		temp.close();
		temp.offset(settings.window_size * 0.5, settings.window_size * 0.5);
		paint.setColor(android.graphics.Color.RED);
		canvas.drawPath(temp, paint);
		paint.setColor(android.graphics.Color.BLACK);
		paint.setStyle(android.graphics.Paint.Style.STROKE);
		canvas.drawPath(temp, paint);
		break;
	case 2:
		temp = android.graphics.Bitmap.createBitmap([ 0, 0, -16777216, 0, 0, 0,
				-16777216, -6250336, -16777216, 0, -16777216, -6250336,
				-2039584, -6250336, -16777216, -16777216, -2039584, -1,
				-2039584, -16777216, -16777216, -2039584, -1, -2039584,
				-16777216, -16777216, -6250336, -2039584, -6250336, -16777216,
				0, -16777216, -16777216, -16777216, 0 ], 5, 7,
				android.graphics.Bitmap.Config.ARGB_8888);
		matrix
				.postScale(displayHeight * 0.005, displayHeight * 0.005, 2.5,
						5.5);
		matrix.postTranslate(settings.window_size * 0.5 - 2.5,
				settings.window_size * 0.5 - 4.5);
		canvas.drawBitmap(temp, matrix, null);
		break;
	case 3:
		break;
	default:
		paint.setColor(android.graphics.Color.BLACK);
		canvas.drawLines([ settings.window_size * 0.2,
				settings.window_size * 0.5, settings.window_size * 0.8,
				settings.window_size * 0.5, settings.window_size * 0.5,
				settings.window_size * 0.2, settings.window_size * 0.5,
				settings.window_size * 0.8 ], paint);
	}
	return bmp;
}
function drawForeground() {
	var bmp = android.graphics.Bitmap.createBitmap(settings.window_size,
			settings.window_size, android.graphics.Bitmap.Config.ARGB_8888), canvas = new android.graphics.Canvas(
			bmp), paint = new android.graphics.Paint();
	paint.setMaskFilter(new android.graphics.EmbossMaskFilter([ 1, 1, 0.3 ],
			0.7, 8, 3 * density));
	switch (settings.style_border) {
	case 1:
		paint.setColor(android.graphics.Color.rgb(153, 135, 108));
		break;
	case 2:
		paint.setColor(0);
		break;
	default:
		paint.setShader(new android.graphics.LinearGradient(0, 0,
				settings.window_size * 0.5, settings.window_size, [
						android.graphics.Color.GREEN,
						android.graphics.Color.YELLOW,
						android.graphics.Color.GREEN ], null,
				android.graphics.Shader.TileMode.REPEAT));
	}
	canvas.drawPath(createPath(true, true), paint);
	return bmp;
}
function createPath(outer, inner) {
	var path = new android.graphics.Path(), size = settings.window_size;
	path.setFillType(android.graphics.Path.FillType.EVEN_ODD);
	if (settings.style_shape) {
		if (inner) {
			path.addCircle(size / 2, size / 2, size / 2 - (7 * density),
					android.graphics.Path.Direction.CW);
		}
		if (outer) {
			path.addCircle(size / 2, size / 2, size / 2,
					android.graphics.Path.Direction.CW);
		}
		return path;
	} else {
		if (inner) {
			path.addRect(7 * density, 7 * density, size - (7 * density), size
					- (7 * density), android.graphics.Path.Direction.CW);
		}
		if (outer) {
			path.addRect(0, 0, size, size, android.graphics.Path.Direction.CW);
		}
		return path;
	}
}
function chunkLoaded(ix, iz) {
	var iy = 130;
	do {
		if (Level.getTile(ix, 130 - iy, iz)) {
			return true;
		}
	} while (iy -= 10);
	return false;
}
mapDot = [
		function basicSurfaceMap(ix, iz) {
			var iy = 130, deltaY = 10, colors = {
				1 : -8487298,
				3 : -7970749,
				4 : -8487298,
				8 : -14000385,
				9 : -14000385,
				10 : -637952,
				11 : -637952,
				12 : -2370656,
				13 : -8618884,
				17 : -10005725,
				18 : -13534192,
				24 : -3817840,
				48 : -10193052,
				78 : -984069,
				79 : -5255937,
				82 : -6314831,
				98 : -8487298,
				99 : -7509421,
				100 : -4774107,
				109 : -8487298,
				110 : -9542807,
				128 : -3817840,
				159 : -2968927,
				161 : -8028101,
				162 : -13293288,
				172 : -6857405,
				174 : -5255937,
				243 : -10797283
			};
			do {
				if (Level.getTile(ix, iy - 10, iz)) {
					if (deltaY === 10) {
						deltaY = 1;
						iy += 10;
					} else {
						return colors[Level.getTile(ix, iy - 10, iz)]
								|| -8540361;
					}
				}
			} while (iy -= deltaY);
			return 0;
		},
		function minecraftMap(ix, iz) {
			var color, block, iy = 130, deltaY = 10, o = android.graphics.Color;
			do {
				if (Level.getTile(ix, iy - 10, iz)) {
					if (deltaY === 10) {
						deltaY = 1;
						iy += 10;
					} else {
						block = Level.getTile(ix, iy - 10, iz);
						switch (block) {
						case 9:
							if (Level.getTile(ix, iy - 19, iz) === 9) {
								return -13882190;
							}
							if (Level.getTile(ix, iy - 16, iz) === 9) {
								return !(ix % 2) === !((iz + 1) % 2) ? -13882190
										: -13224231;
							}
							if (Level.getTile(ix, iy - 14, iz) === 9) {
								return -13224231;
							}
							if (Level.getTile(ix, iy - 12, iz) === 9) {
								return !(ix % 2) === !((iz + 1) % 2) ? -13224231
										: -12632068;
							}
							return -12632068;
						case 12:
							if (Level.getData(ix, iy - 10, iz)) {
								color = 0xd57d32;
							} else {
								color = 0xf4e6a1;
							}
							break;
						case 35:
						case 159:
						case 171:
							color = [ 0xfcf9f2, 0xd57d32, 0xb04bd5, 0x6597d5,
									0xe2e232, 0x7dca19, 0xef7da3, 0x4b4b4b,
									0x979797, 0x4b7d97, 0x7d3eb0, 0x324bb0,
									0x654b32, 0x657d32, 0x973232, 0x191919 ][Level
									.getData(ix, iy - 10, iz)];
							break;
						case 5:
						case 85:
						case 157:
						case 158:
							color = [ 0x8d7647, 0x7e5430, 0xf4e6a1, 0x956c4c,
									0xd57d32, 0x654b32, 0, 0, 0x8d7647,
									0x7e5430, 0xf4e6a1, 0x956c4c, 0xd57d32,
									0x654b32, 0, 0 ][Level.getData(ix, iy - 10,
									iz)];
							break;
						case 43:
						case 44:
							color = [ 0x6f6f6f, 0xf4e6a1, 0x8d7647, 0x6f6f6f,
									0x973232, 0x6f6f6f, 0xfcfcfc, 0x6f0200,
									0x6f6f6f, 0xf4e6a1, 0x8d7647, 0x6f6f6f,
									0x973232, 0x6f6f6f, 0xfcfcfc, 0x6f0200 ][Level
									.getData(ix, iy - 10, iz)];
							break;
						default:
							color = {
								2 : 0x7db037,
								3 : 0x956c4c,
								6 : 0x007b00,
								8 : 0x3f3ffc,
								10 : 0xfc0000,
								11 : 0xfc0000,
								17 : 0x8d7647,
								18 : 0x007b00,
								19 : 0xe2e232,
								22 : 0x4981fc,
								24 : 0xf4e6a1,
								30 : 0xfcfcfc,
								31 : 0x007b00,
								32 : 0x8d7647,
								37 : 0x007b00,
								38 : 0x007b00,
								39 : 0x007b00,
								40 : 0x007b00,
								41 : 0xf7eb4c,
								42 : 0xa5a5a5,
								45 : 0x973232,
								46 : 0xfc0000,
								47 : 0x8d7647,
								49 : 0x191919,
								53 : 0x8d7647,
								54 : 0x8d7647,
								57 : 0x5bd8d2,
								59 : 0x007b00,
								60 : 0x956c4c,
								78 : 0xfcfcfc,
								79 : 0x9e9efc,
								80 : 0xfcfcfc,
								81 : 0x007b00,
								82 : 0xa2a6b6,
								83 : 0x007b00,
								86 : 0xd57d32,
								87 : 0x6f0200,
								91 : 0xd57d32,
								99 : 0x8d7647,
								100 : 0x973232,
								103 : 0x7dca19,
								104 : 0x007b00,
								105 : 0x007b00,
								106 : 0x007b00,
								107 : 0x8d7647,
								108 : 0x973232,
								110 : 0x7d3eb0,
								111 : 0x007b00,
								112 : 0x6f0200,
								114 : 0x6f0200,
								121 : 0xf4e6a1,
								128 : 0xf4e6a1,
								133 : 0x00d639,
								134 : 0x7e5430,
								135 : 0xf4e6a1,
								136 : 0x956c4c,
								141 : 0x007b00,
								142 : 0x007b00,
								155 : 0xfcfcfc,
								156 : 0xfcfcfc,
								161 : 0x007b00,
								162 : 0x8d7647,
								163 : 0xd57d32,
								164 : 0x654b32,
								170 : 0xf7eb4c,
								172 : 0xd57d32,
								174 : 0x9e9efc,
								175 : 0x007b00,
								183 : 0x7e5430,
								184 : 0xf4e6a1,
								185 : 0x956c4c,
								187 : 0xd57d32,
								186 : 0x654b32,
								243 : 0x7e5430,
								244 : 0x007b00
							};
							color = color[block] || 0x6f6f6f;
						}
						if (Level.getTile(ix - 1, iy - 9, iz)) {
							return o.rgb(o.red(color) * (180 / 255), o
									.green(color)
									* (180 / 255), o.blue(color) * (180 / 255));
						}
						if (Level.getTile(ix - 1, iy - 10, iz)) {
							return o.rgb(o.red(color) * (220 / 255), o
									.green(color)
									* (220 / 255), o.blue(color) * (220 / 255));
						}
						return o.rgb(o.red(color), o.green(color), o
								.blue(color));
					}
				}
			} while (iy -= deltaY);
			return 0;
		},
		function caveMap(ix, iz) {
			var count = 0, block = 1, blockNew, iy = 96, y, r, g, b, increment = 3;
			do {
				blockNew = Level.getTile(ix, iy - 3, iz);
				switch (blockNew) {
				case 0:
				case 17:
				case 18:
				case 20:
				case 50:
				case 64:
				case 66:
				case 106:
				case 127:
				case 161:
				case 162:
					blockNew = 1;
					break;
				case 8:
				case 9:
					blockNew = 0;
					if (count > 1) {
						r = r || 1;
						g = g || 1;
						b = b || 255;
						blockNew = 1
					}
					break;
				case 10:
				case 11:
					blockNew = 0;
					if (count > 1) {
						r = r || 255;
						g = g || 1;
						b = b || 1;
						blockNew = 1
					}
					break;
				case 4:
				case 48:
					blockNew = 2;
					if (count > 2) {
						r = r || 1;
						g = g || 255;
						b = b || 255
					}
					break;
				case 97:
				case 98:
					blockNew = 2;
					if (count > 2) {
						r = r || 255;
						g = g || 1;
						b = b || 255
					}
					break;
				default:
					blockNew = 2;
				}
				if (blockNew !== block) {
					count += blockNew;
					y = iy
				}
				if (count === 5) {
					iy += 3;
					increment = 1;
					count = 6;
					blockNew = 1;
				} else if (count === 8) {
					r = r || 150;
					g = g || 255;
					b = b || 0;
					return android.graphics.Color.rgb(r
							* (0.8 * (y / 127) + 0.2), g
							* (0.9 * (y / 127) + 0.1), b
							* (0.9 * (y / 127) + 0.1));
				}
				block = blockNew;
			} while (iy -= increment);
			y = y || 127;
			r = 255;
			g = 255;
			b = 255;
			return android.graphics.Color.rgb(r * (0.8 * (y / 127) + 0.2), g
					* (0.8 * (y / 127) + 0.2), b * (0.8 * (y / 127) + 0.2));
		} ];
function checkRenderDistance() {
	var options = load(
			android.os.Environment.getExternalStorageDirectory().getPath()
					+ "/games/com.mojang/minecraftpe/", "options.txt").split(
			"\n"), i;
	if (options != "") { // not !==
		for (i = 0; i < options.length; i += 1) {
			options[i] = options[i].split(":");
			if (options[i][0] === "gfx_renderdistance_new") {
				return Math.round(parseInt(options[i][1], 10) / 16);
			}
		}
	}
	return 6;
}
function saveSettings() {
	var settingsString = "", p;
	for (p in settings) {
		if (settings.hasOwnProperty(p)) {
			if (settingsString !== "") {
				settingsString += "\n";
			}
			settingsString += p + ":" + settings[p];
		}
	}
	save(android.os.Environment.getExternalStorageDirectory().getPath()
			+ "/games/com.mojang/minecraftpe/mods/", "minimap.txt",
			settingsString);
}
function settingsChanged(key) {
	switch (key) {
	case "radius":
		var i, j, widthOld = bmpSrc.getWidth(), widthNew = ((settings.radius + 1) * 2 + 1) * 16, xChunk = Math
				.floor(X / 16) * 16, zChunk = Math.floor(Z / 16) * 16;
		try {
			bmpSrcLock.acquire();
			bmpSrcCopy = android.graphics.Bitmap.createBitmap(widthNew,
					widthNew, android.graphics.Bitmap.Config.ARGB_8888);
			canvasBmpSrcCopy.setBitmap(bmpSrcCopy);
			canvasBmpSrcCopy.drawBitmap(bmpSrc, (widthNew - widthOld) / 2,
					(widthNew - widthOld) / 2, null);
			bmpSrc = android.graphics.Bitmap.createBitmap(widthNew, widthNew,
					android.graphics.Bitmap.Config.ARGB_8888);
			canvasBmpSrc.setBitmap(bmpSrc);
			canvasBmpSrc.drawBitmap(bmpSrcCopy, 0, 0, null);
		} finally {
			bmpSrcLock.release();
		}
		minZoom = settings.window_size / (settings.radius * 2 * 16);
		if (widthNew > widthOld) {
			for (i = (widthOld - 16) / 2; i <= settings.radius * 16; i += 16) {
				for (j = 0; j < i; j += 16) {
					if (settings.map_on) {
						newDrawChunkRunnable(xChunk + j + 16, zChunk + i, 0);
						newDrawChunkRunnable(xChunk + j, zChunk - i, 0);
						newDrawChunkRunnable(xChunk - j, zChunk + i, 0);
						newDrawChunkRunnable(xChunk - j - 16, zChunk - i, 0);
						newDrawChunkRunnable(xChunk + i, zChunk + j, 0);
						newDrawChunkRunnable(xChunk + i, zChunk - j - 16, 0);
						newDrawChunkRunnable(xChunk - i, zChunk + j + 16, 0);
						newDrawChunkRunnable(xChunk - i, zChunk - j, 0);
					} else {
						delayChunksArrLock.acquire();
						delayChunksArr[delayChunksArr.length] = [
								xChunk + j + 16, zChunk + i ];
						delayChunksArr[delayChunksArr.length] = [ xChunk + j,
								zChunk - i ];
						delayChunksArr[delayChunksArr.length] = [ xChunk - j,
								zChunk + i ];
						delayChunksArr[delayChunksArr.length] = [
								xChunk - j - 16, zChunk - i ];
						delayChunksArr[delayChunksArr.length] = [ xChunk + i,
								zChunk + j ];
						delayChunksArr[delayChunksArr.length] = [ xChunk + i,
								zChunk - j - 16 ];
						delayChunksArr[delayChunksArr.length] = [ xChunk - i,
								zChunk + j + 16 ];
						delayChunksArr[delayChunksArr.length] = [ xChunk - i,
								zChunk - j ];
						delayChunksArrLock.release();
					}
				}
			}
		}
		redraw = true;
		break;
	case "map_on":
		var i;
		if (settings.map_on) {
			pool = java.util.concurrent.Executors
					.newScheduledThreadPool(settings.threadCount);
			pool.setKeepAliveTime(60, java.util.concurrent.TimeUnit.SECONDS);
			pool.allowCoreThreadTimeOut(true);
			delayChunksArrLock.acquire();
			i = delayChunksArr.length;
			while (i--) {
				newDrawChunkRunnable(delayChunksArr[i][0],
						delayChunksArr[i][1], 0);
			}
			delayChunksArr = [];
			delayChunksArrLock.release();
			scheduledFutureUpdateMap = poolTick.scheduleWithFixedDelay(
					runnableUpdateMap, 1000, Math.round(1000 / settings.delay),
					java.util.concurrent.TimeUnit.MILLISECONDS);
			newDrawChunkRunnable(Math.floor(X / 16) * 16,
					Math.floor(Z / 16) * 16, 0);
		} else {
			pool.shutdown();
			scheduledFutureUpdateMap.cancel(false);
		}
		mapWindow.reset("visibility");
		break;
	case "map_type":
		if (settings.map_on) {
			pool.shutdownNow();
			pool = java.util.concurrent.Executors
					.newScheduledThreadPool(settings.threadCount);
			pool.setKeepAliveTime(60, java.util.concurrent.TimeUnit.SECONDS);
			pool.allowCoreThreadTimeOut(true);
		}
		X = undefined;
		break;
	case "map_zoom":
		redraw = true;
		break;
	case "window_rawSize":
		mapWindow.reset("size");
		mapWindow.reset("window");
		mapWindow.reset("pointer");
		minZoom = settings.window_size / (settings.radius * 2 * 16);
		break;
	case "window_rawPosition":
		mapWindow.reset("position");
		break;
	case "style_shape":
	case "style_border":
		mapWindow.reset("window");
		break;
	case "style_pointer":
		mapWindow.reset("pointer");
		break;
	case "show_info":
	case "show_zoomBtn":
		mapWindow.reset("visibility");
		break;
	case "delay":
		scheduledFutureUpdateMap.cancel(false);
		scheduledFutureUpdateMap = poolTick.scheduleWithFixedDelay(
				runnableUpdateMap, 1000, Math.round(1000 / settings.delay),
				java.util.concurrent.TimeUnit.MILLISECONDS);
		break;
	case "threadCount":
		pool.setCorePoolSize(settings.threadCount);
		break;
	}
}

function settingsClosed() {
	saveSettings();
}

/**
 * setting window
 */
function settingsUI() {
	var textSize = 17, // sp: scaled pixels
	padding = 10, // dp: density pixels
	context = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(), alert = new android.app.AlertDialog.Builder(
			context), scroll = new android.widget.ScrollView(context), layout = new android.widget.LinearLayout(
			context), i, len = arguments[0].length, ruler, rulerLp = new android.view.ViewGroup.LayoutParams(
			android.view.ViewGroup.LayoutParams.MATCH_PARENT, 2), addOption = {
		checkBox : function(args) {
			var layoutElement = new android.widget.RelativeLayout(context), checkBtn = new android.widget.CheckBox(
					context), checkBtnLp = new android.widget.RelativeLayout.LayoutParams(
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT), text = new android.widget.TextView(
					context), textLp = new android.widget.RelativeLayout.LayoutParams(
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
			text.setTextSize(textSize);
			text.setText(args[2]);
			checkBtn.setId(1);
			checkBtn.setChecked(Boolean(settings[args[1]]));
			checkBtn
					.setOnCheckedChangeListener(function(buttonView, isChecked) {
						if (isChecked) {
							settings[args[1]] = 1;
						} else {
							settings[args[1]] = 0;
						}
						settingsChanged(args[1]);
					});
			checkBtnLp
					.addRule(android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
			checkBtnLp.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
			textLp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_LEFT);
			textLp.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
			textLp.addRule(android.widget.RelativeLayout.LEFT_OF, 1);
			layoutElement.addView(checkBtn, checkBtnLp);
			layoutElement.addView(text, textLp);
			layoutElement.setPadding(padding, padding * 0.5, padding,
					padding * 0.5);
			return layoutElement;
		},
		subScreen : function(args) {
			var text = new android.widget.TextView(context);
			text.setTextSize(textSize);
			text.setText(args[1] + " >");
			text.setPadding(padding, padding, padding, padding);
			text.setOnClickListener(function(v) {
				settingsUI(args[2]).show();
			});
			return text;
		},
		sectionDivider : function(args) {
			var text = new android.widget.TextView(context);
			text.setTextSize(textSize * 0.9);
			text.setText(args[1]);
			text.setTextColor(android.graphics.Color.WHITE)
			text
					.setBackgroundDrawable(new android.graphics.drawable.GradientDrawable(
							android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
							[ android.graphics.Color.rgb(0, 127, 0),
									android.graphics.Color.rgb(63, 95, 0),
									android.graphics.Color.rgb(0, 63, 0) ]));
			text.setPadding(padding, 0, padding, 0);
			return text;
		},
		keyValue : function(args) {
			var layoutElement = new android.widget.RelativeLayout(context), text = new android.widget.TextView(
					context), textLp = new android.widget.RelativeLayout.LayoutParams(
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT), textValue = new android.widget.TextView(
					context), textValueLp = new android.widget.RelativeLayout.LayoutParams(
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT,
					android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
			text.setTextSize(textSize);
			text.setText(String(args[2]));
			textValue.setTextSize(textSize);
			textValue.setTextColor(android.graphics.Color.rgb(100, 255, 0));
			textValue.setId(1);
			switch (args[1]) {
			case "multipleChoice":
				if (args[4].length <= settings[args[3]]) {
					settings[args[3]] = 0
				}
				textValue.setText(args[4][settings[args[3]]]);
				layoutElement
						.setOnClickListener(function(v) {
							var alert = new android.app.AlertDialog.Builder(
									context), listView = new android.widget.ListView(
									context), adapter = new android.widget.ArrayAdapter(
									context,
									android.R.layout.simple_list_item_single_choice,
									args[4]);
							listView.setAdapter(adapter);
							listView
									.setChoiceMode(android.widget.ListView.CHOICE_MODE_SINGLE);
							listView.setItemChecked(settings[args[3]], true);
							listView
									.setDivider(new android.graphics.drawable.GradientDrawable(
											android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
											[
													android.graphics.Color.GREEN,
													android.graphics.Color.YELLOW,
													android.graphics.Color.GREEN ]));
							listView.setDividerHeight(2);
							listView.setPadding(padding, padding, padding,
									padding);
							listView.setOnItemClickListener(function(parent,
									view, position, id) {
								settings[args[3]] = position;
								for ( var i = 5; i < args.length; i += 2) {
									settings[args[i]] = args[i + 1][position];
								}
								textValue.setText(args[4][position]);
								settingsChanged(args[3]);
								alert.dismiss();
							});
							alert.setView(listView);
							alert.setTitle(args[2]);
							alert.setNegativeButton("Close QQ", function(dialog,
									whichButton) {
								alert.dismiss();
							});
							alert = alert.show();
						});
				break;
			case "slider":
				textValue.setText(settings[args[3]] + args[7]);
				textValue
						.setOnClickListener(function(v) {
							var alert = new android.app.AlertDialog.Builder(
									context), seekBar = new android.widget.SeekBar(
									context);
							seekBar.setMax((args[5] - args[4]) / args[6]);
							seekBar.setProgress((settings[args[3]] - args[4])
									/ args[6]);
							seekBar
									.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(
											{
												onProgressChanged : function(
														seekBar, progress,
														fromUser) {
													alert
															.setTitle(args[2]
																	+ "  "
																	+ (progress
																			* args[6] + args[4])
																	+ args[7]);
												}
											}));
							alert.setView(seekBar);
							alert.setTitle(args[2] + "  " + settings[args[3]]
									+ args[7]);
							alert.setPositiveButton("Ok", function(dialog,
									whichButton) {
								settings[args[3]] = seekBar.getProgress()
										* args[6] + args[4];
								textValue.setText(settings[args[3]] + args[7]);
								settingsChanged(args[3]);
								alert.dismiss();
							});
							alert.setNegativeButton("Cancel", function(dialog,
									whichButton) {
								alert.dismiss();
							});
							alert = alert.show();
						});
				break;
			default:
				textValue.setText(String(args[3]));
			}
			textLp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_LEFT);
			textLp.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
			textLp.addRule(android.widget.RelativeLayout.LEFT_OF, 1);
			textValueLp
					.addRule(android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
			textValueLp.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
			layoutElement.addView(textValue, textValueLp);
			layoutElement.addView(text, textLp);
			layoutElement.setPadding(padding, padding, padding, padding);
			return layoutElement;
		}
	};
	padding = padding * context.getResources().getDisplayMetrics().density;
	layout.setOrientation(android.widget.LinearLayout.VERTICAL);
	layout.setPadding(padding, 0, padding, 0);
	for (i = 2; i < len; i += 1) {
		layout.addView(addOption[arguments[0][i][0]](arguments[0][i]));
		if (i + 1 < len) {
			ruler = new android.view.View(context);
			ruler
					.setBackgroundDrawable(new android.graphics.drawable.GradientDrawable(
							android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
							[ android.graphics.Color.GREEN,
									android.graphics.Color.YELLOW,
									android.graphics.Color.GREEN ]));
			layout.addView(ruler, rulerLp);
		}
	}
	scroll.addView(layout);
	alert.setView(scroll);
	alert.setTitle(arguments[0][0]);
	alert.setPositiveButton(arguments[0][1], function(dialog, whichButton) {
		settingsClosed();
	});
	return alert;
}
function save(path, filename, content) {
	try {
		java.io.File(path).mkdirs();
		var newFile = new java.io.File(path, filename);
		newFile.createNewFile();
		var outWrite = new java.io.OutputStreamWriter(
				new java.io.FileOutputStream(newFile));
		outWrite.append(content);
		outWrite.close();
	} catch (e) {
		//print("save, " + e);
	}
}
function load(path, filename) {
	var content = "";
	if (java.io.File(path + filename).exists()) {
		var file = new java.io.File(path + filename), fos = new java.io.FileInputStream(
				file), str = new java.lang.StringBuilder(), ch;
		while ((ch = fos.read()) != -1) {
			str.append(java.lang.Character(ch));
		}
		content = String(str.toString());
		fos.close();
	}
	return content;
}
function loadTxtFromUrl(url) {
	try {
		var content = new java.io.ByteArrayOutputStream();
		android.net.http.AndroidHttpClient.newInstance("userAgent").execute(
				new org.apache.http.client.methods.HttpGet(url)).getEntity()
				.writeTo(content);
		content.close();
		return String(content.toString());
	} catch (e) {
		return "";
	}
}
function enable_script_func() {
	enable_script_var = 1;
}

function disable_script_func() {
	enable_script_var = 0;
}